#include "../lib/morpion.h"
#include "../lib/sauvegarde.h"

int main(){

    int grille[N][N];
    int morpion[M][M];

    printf("============ Début du test pour les fonctions screens\n");
    init_grille(grille);
    init_morpion(morpion);
    

    return 0;
}